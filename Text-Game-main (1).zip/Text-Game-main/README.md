# Text-Game

- Text based adventure game in C for second sem project.
- Replace system("clear") with system("cls") if running on Windows.
- Link src and cli files after compiling
